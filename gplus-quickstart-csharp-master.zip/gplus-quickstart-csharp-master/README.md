# Google+ C#/.NET Quickstart

The instructions are now here:
https://developers.google.com/+/quickstart/csharp
